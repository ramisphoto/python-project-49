### Hexlet tests and linter status:
[![Actions Status](https://github.com/ramisphoto/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ramisphoto/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/99b0d981cd00b575104c/maintainability)](https://codeclimate.com/github/ramissabirzyanov/python-project-49/maintainability)
![example of brain-even](https://asciinema.org/a/3X5zfT2XkzE818OXHaekJT18a)
![example of brain-calc](https://asciinema.org/a/p72Z7jyeBa8P7wdHnjrrcvrDe)
