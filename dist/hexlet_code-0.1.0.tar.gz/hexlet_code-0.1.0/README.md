### Hexlet tests and linter status:
[![Actions Status](https://github.com/ramisphoto/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ramisphoto/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/99b0d981cd00b575104c/maintainability)](https://codeclimate.com/github/ramissabirzyanov/python-project-49/maintainability)
![example of brain-even](https://asciinema.org/connect/8c642826-068c-4a98-ba2f-f6367ce14af8)
