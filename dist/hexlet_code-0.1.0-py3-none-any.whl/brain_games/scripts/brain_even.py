from brain_games.games import even
from brain_games.game_engine import engine


def main():
    engine(even)


if __name__ == '__main__':
    main()
